import java.util.ArrayList;

import com.dao.DAO;
import com.user.UserBean;

public class MainCLass {

	public static void main(String[] args) throws Exception {
		DAO dao=new DAO();
		
		  String user=dao.getUserType("AB1001");
		  
		  UserBean ub=new UserBean("AB1002", "AB1002", "Admin1", 0, 0, "Admin"); String
		  res=dao.addUser(ub);
		  
		  dao.changeName("RS1007", "Subhanbee");
		  
		  String reu=dao.changePassword("Admin1234");
		  
		  String reu1=dao.changeUserType("RS1007");
		  
		  dao.getIncorrectAttempts("AB1002");
		  
		  int reu2=dao.getLockStatus();
		  
		  ArrayList<UserBean> al=dao.getUsers("Employee"); for(int i=0;i<al.size();i++)
		  { System.out.println(al.get(i).getID());}
		  
		  String[] al1=dao.getNames(); for(String s:al1) { System.out.println(s); }
		 
		
		ArrayList<UserBean> al2=dao.storeAllRecords();
		for(UserBean us:al2) {
			System.out.println(us.getID());
		}
	

	}

}
