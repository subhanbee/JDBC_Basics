package com.user;

public class UserBean {
	
	private String ID;
	private String password;
	private String name;
	private int incorrectAttempts;
	private int lockStatus;
	private String userYype;
	public UserBean(String iD, String password, String name, int incorrectAttempts, int lockStatus, String userYype) {
		super();
		ID = iD;
		this.password = password;
		this.name = name;
		this.incorrectAttempts = incorrectAttempts;
		this.lockStatus = lockStatus;
		this.userYype = userYype;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIncorrectAttempts() {
		return incorrectAttempts;
	}
	public void setIncorrectAttempts(int incorrectAttempts) {
		this.incorrectAttempts = incorrectAttempts;
	}
	public int getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(int lockStatus) {
		this.lockStatus = lockStatus;
	}
	public String getUserYype() {
		return userYype;
	}
	public void setUserYype(String userYype) {
		this.userYype = userYype;
	}
	
	

}
