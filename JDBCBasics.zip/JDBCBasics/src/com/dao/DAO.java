package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.user.UserBean;

public class DAO {
	public static Connection getDBConn() throws Exception
	{
		Connection con=null;
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hb_student_tracker","hbstudent","hsbcstudent");
		return con;
	}

	
	public String getUserType(String userID) throws Exception {
		Connection con=DAO.getDBConn();
		PreparedStatement pst=con.prepareStatement("select UserType from user where UserId=?");
		pst.setString(1,userID);
		ResultSet rs=pst.executeQuery();
		String userType=null;
		while(rs.next()) {
			 userType=rs.getString(1);
			
		}
		return userType;
		
	}
	
	  public String getIncorrectAttempts(String userID) throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("select IncorrectAttempts from user where UserId=?");
			pst.setString(1,userID);
			ResultSet rs=pst.executeQuery();
			Integer inc=null;
			while(rs.next()) {
				 inc=rs.getInt(1);
				
			}
			if(inc==0)
			
			return "No Incorrect Attempt";
			
			else if(inc==1)
			
				return "One Time";	
			
			else 
				 return "Incorrect Attempt Exceeded";
	  
	  } 
	  public String changeUserType(String userID) throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("update user set UserType=? where UserId=?");
			pst.setString(1,"Admin");
			pst.setString(2, userID);
			int result=pst.executeUpdate();
			if(result>=1) {
				return "Update Success";
			}
			else
				return "�Update Failed�";
	  
	  } 
	  public int getLockStatus() throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("select LockStatus from user");
			ResultSet rs=pst.executeQuery();
			int count=0;
			while(rs.next()) {
				if(rs.getInt(1)==0) {
				count++;}
			}
			return count;
		 } 
	  public String changeName(String id, String name) throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("update user set Name=? where UserId=?");
			pst.setString(1,name);
			pst.setString(2, id); 
			int i=pst.executeUpdate();
			if(i>=1)
			{
				return "Success";
			}
			else
				return "Failed";
	  
	  } public String changePassword(String password) throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("update user set Password=? where UserType=?");
			pst.setString(1,password);
			pst.setString(2, "Admin");
			int i=pst.executeUpdate();
			if(i>=1)
			{
				return "Success";
			}
			else
				return "0";
	  
	  } 
	  public String addUser(UserBean bean) throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("insert into user values(?,?,?,?,?,?)");
			pst.setString(1,bean.getID());
			pst.setString(2,bean.getPassword());
			pst.setString(3,bean.getName());
			pst.setInt(4, bean.getIncorrectAttempts());
			pst.setInt(5, bean.getLockStatus());
			pst.setString(6, bean.getUserYype());
			int reu=pst.executeUpdate();
			if(reu>=1)
				return "Success";
			else
				return "Failure";
	  } 
	  
	  public ArrayList<UserBean> getUsers(String userType) throws Exception{
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("select * from user where UserType=?");
			pst.setString(1,userType);
			ResultSet rs=pst.executeQuery();
			ArrayList<UserBean> al=new ArrayList<UserBean>();
			while(rs.next()) {
				UserBean ub=new UserBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getString(6));
				al.add(ub);
			}
			return al;
	  
	  } public ArrayList<UserBean> storeAllRecords() throws Exception{
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("select * from user");
			ResultSet rs=pst.executeQuery();
			ArrayList<UserBean> al=new ArrayList<UserBean>();
			while(rs.next()) {
				UserBean ub=new UserBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getString(6));
				al.add(ub);
			}
			return al;
	  
	  
	  } public String[] getNames() throws Exception {
		  Connection con=DAO.getDBConn();
			PreparedStatement pst=con.prepareStatement("select Name from user");
			ResultSet rs=pst.executeQuery();
			String[] all=new String[10];
			int i=0;
			while(rs.next()) {
				String s= rs.getString(1);
				all[i]=new String(s);
				++i;}
			return all;
	  
	  
	  }
	 
}